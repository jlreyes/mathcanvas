/* 
 * Constants for index.html 
 */
/// <reference path="globals.ts"/>
module Constants {
    export var TRANS_END_NAME : string = "transitionend webkitTransitionEnd oTransitionEnd MSTransitionEnd";
}