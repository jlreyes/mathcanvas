/*
 * Mobile view for the login page.
 */
/// <reference path="../imports.ts"/>

class ChatMobileView extends ChatView {
    private static sTemplate : Template = new Template("page-chat-mobile");
}