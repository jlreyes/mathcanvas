/* Declarations */
/// <reference path="../../lib/user.d.ts"/>
/// <reference path="../../lib/app.d.ts"/>
/// <reference path="../../lib/room.d.ts"/>
/// <reference path="../../lib/jquery.d.ts"/>
/* Page files */
/// <reference path="./ChatPage.ts"/>
/* Views */
/// <reference path="./ChatView.ts"/>
/// <reference path="./views/ChatMobileView.ts"/>
declare var dust;