/*
 * Mobile view for the login page.
 */
/// <reference path="../imports.ts"/>

class RoomMobileView extends RoomView {
    private static sTemplate : Template = new Template("page-room-mobile");
}