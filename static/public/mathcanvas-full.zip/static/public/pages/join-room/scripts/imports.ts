/* Declarations */
/// <reference path="../../lib/user.d.ts"/>
/// <reference path="../../lib/app.d.ts"/>
/// <reference path="../../lib/room.d.ts"/>
/// <reference path="../../lib/jquery.d.ts"/>
/* Page files */
/// <reference path="./JoinRoomPage.ts"/>
/* Views */
/// <reference path="./JoinRoomView.ts"/>
/// <reference path="./views/JoinRoomMobileView.ts"/>
/// <reference path="./views/dialog-create-room.ts"/>
declare var dust;