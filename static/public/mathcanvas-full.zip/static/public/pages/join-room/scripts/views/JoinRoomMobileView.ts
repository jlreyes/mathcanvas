/*
 * Mobile view for the login page.
 */
/// <reference path="../imports.ts"/>

class JoinRoomMobileView extends JoinRoomView {
    private static sTemplate : Template = new Template("page-join-room-mobile");
}