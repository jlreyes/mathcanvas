/* Declarations */
/// <reference path="../../lib/user.d.ts"/>
/// <reference path="../../lib/room.d.ts"/>
/// <reference path="../../lib/app.d.ts"/>
/// <reference path="../../lib/jquery.d.ts"/>
/* Page files */
/// <reference path="./LoginPage.ts"/>
/* Views */
/// <reference path="./LoginView.ts"/>
/// <reference path="./views/LoginMobileView.ts"/>

declare var Recaptcha;