/*
 * Mobile view for the login page.
 */
/// <reference path="../imports.ts"/>

class LoginMobileView extends LoginView {
    private static sTemplate : Template = new Template("page-login-mobile");
}